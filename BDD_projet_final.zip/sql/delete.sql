drop table if exists ChefLieuDep cascade;
drop table if exists ChefLieuReg cascade;

drop table if exists StatsPopulation cascade;
drop table if exists StatsLibelle cascade;

drop table if exists DatasStatsMariage cascade;
drop table if exists CategorieStats cascade;
drop table if exists TypeCategorie cascade;
drop table if exists StatistiqueMariage cascade;

drop table if exists Commune cascade;
drop table if exists Departement cascade;
drop table if exists Region cascade;


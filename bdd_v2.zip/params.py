params = {
    "sql_requete" : {  
        "create_sql" : "./sql/create.sql", 
        "delete_sql" : "./sql/delete.sql",
    },
    "csv_historique" : {
        "meta_cc_serie_historique_2020" : "./csv/historique_2020/meta_base-cc-serie-historique-2020.CSV",
        "base_cc_serie_historique_2020" : "./csv/historique_2020/base-cc-serie-historique-2020.CSV",
    },
    "csv_mariage" : {
        "dep1": {
            "fichier" : "./csv/mariage/Dep1.csv",
            "titre" : "Groupe d'âges des époux selon le département et la région de mariage. Année 2021",
        },
        "dep2": {
            "fichier" : "./csv/mariage/Dep2.csv",
            "titre" : "État matrimonial antérieur des époux selon le département et la région de mariage. Année 2021",
        },
        "dep3": {
            "fichier" : "./csv/mariage/Dep3.csv",
            "titre" : "Groupe d'âges des époux se mariant pour la première fois selon le département et la région de mariage. Année 2021",
        },
        "dep4": {
            "fichier" : "./csv/mariage/Dep4.csv",
            "titre" : "Nationalité des époux selon le département et la région de domicile conjugal. Année 2021",
        },
        "dep5": {
            "fichier" : "./csv/mariage/Dep5.csv",
            "titre" : "Pays de naissance des époux selon le département et la région de domicile conjugal. Année 2021",
        },
        "dep6": {
            "fichier" : "./csv/mariage/Dep6.csv",
            "titre" : "Répartition mensuelle des mariages selon le département et la région de mariage. Année 2021",
        },
    },
    "cog" : {
        "v_commune_2023" : "./csv/cog/v_commune_2023.csv",
        "v_departement_2023" : "./csv/cog/v_departement_2023.csv",
        "v_region_2023" : "./csv/cog/v_region_2023.csv",
    }
}
from lib import initialise_db, login_bdd, insert_stats_population_fragment, insert_dep_file_fragment
from params import params

connection = login_bdd("bddproject_db", "root", "root", "localhost", verbose=True)
initialise_db(connection, params, flag_reset_bdd=True)

# Importe seulment les statistiques de populations des lignes de 5 à 20 premieres  
insert_stats_population_fragment(connection, params, init_metadonnee = True,  first=5, last = 20, verbose=True)  
insert_stats_population_fragment(connection, params, first=21, last = 30, verbose=True) 
# Vous pouvez passer last à null pour tout importer 
insert_stats_population_fragment(connection, params, first=31, verbose=True) 
# Importe seulement les 21 premieres lignes de tout les fichiers des statistiques sur les mariages (DEP 1 à 6)
insert_dep_file_fragment(connection, params, "2021", last = 20, verbose=True) 
# Importe toutes les statistiques de mariage
insert_dep_file_fragment(connection, params,"2021", first=21, last = None, verbose=True)  

connection.close()
def get_last_stat_id(connection):
    """
    Reccupere le dernier id (le plus élevé) dans la table StatistiqueMariage.
    Renvoie 0 si la table est vide
    """
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT MAX(id) FROM StatistiqueMariage;")
        last_stat_id = cursor.fetchone()[0]
        cursor.close()
        if last_stat_id : return last_stat_id 
        else: return 0
    except Exception as e:
        raise e


def get_departments_in_region(connection, region_id):
    """
    Reccupere la liste des departement d'une region
    """
    cursor = connection.cursor()
    cursor.execute("SELECT dep, ncc FROM Departement WHERE id_reg = %s", (region_id,))
    departments = cursor.fetchall()
    cursor.close()
    return departments


def get_communes_with_population_greater_than(connection, department_id, greater_than):
    """
    Récupére la liste des communes avec une population supérieure à X dans un département donné
    """
    cursor = connection.cursor()
    cursor.execute(" SELECT comm.com, comm.ncc FROM Commune comm, StatsPopulation sp  WHERE sp.id_com = comm.com AND comm.id_dep = '%s' AND sp.valeur > %s", (department_id, greater_than))
    communes = cursor.fetchall()
    cursor.close()
    return communes


def get_most_populated_commune(cursor, id_dep):
    """
    Récupérer la commune la plus peuplée d'un département
    """
    query = """
        SELECT com, ncc AS commune_name, valeur AS population
        FROM Commune
        JOIN StatsPopulation ON Commune.com = StatsPopulation.id_com
        WHERE id_dep = '%s'
        ORDER BY valeur DESC
        LIMIT 1;
    """
    cursor.execute(query, (id_dep,))
    return cursor.fetchone()


def get_least_populated_commune(cursor, id_dep):
    """
    Récupérer la commune la moins peuplée d'un département
    """
    query = """
        SELECT com, ncc AS commune_name, valeur AS population
        FROM Commune
        JOIN StatsPopulation ON Commune.com = StatsPopulation.id_com
        WHERE id_dep = '%s'
        ORDER BY valeur
        LIMIT 1;
    """
    cursor.execute(query, (id_dep,))
    return cursor.fetchone()



def get_most_populated_region(cursor):
    """
    Récupére la région la plus peuplée
    """
    query = """
        SELECT reg, Region.ncc AS region_name, SUM(valeur) AS total_population
        FROM Commune
        JOIN StatsPopulation ON Commune.com = StatsPopulation.id_com
        JOIN Departement ON Commune.id_dep = Departement.dep
        JOIN Region ON Departement.id_reg = Region.reg
        GROUP BY reg, region_name
        ORDER BY total_population DESC
        LIMIT 1;
    """
    cursor.execute(query)
    return cursor.fetchone()


def get_least_populated_region(cursor):
    """
    Récupére la région la moins peuplée
    """
    query = """
        SELECT reg, Region.ncc AS region_name, SUM(valeur) AS total_population
        FROM Commune
        JOIN StatsPopulation ON Commune.com = StatsPopulation.id_com
        JOIN Departement ON Commune.id_dep = Departement.dep
        JOIN Region ON Departement.id_reg = Region.reg
        GROUP BY reg, region_name
        ORDER BY total_population
        LIMIT 1;
    """
    cursor.execute(query)
    return cursor.fetchone()